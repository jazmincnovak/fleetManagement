import { Router } from 'express'

const r = Router()

// Simple mock login. Replace with real JWT auth later.
r.post('/login', (req, res) => {
  const { email } = req.body || {}
  const token = Buffer.from(`${email}:${Date.now()}`).toString('base64')
  res.json({ token })
})

export default r