import { Router } from 'express'
import { prisma } from '../utils/prisma.js'

const r = Router()

r.post('/', async (req, res) => {
  const { vehicle, items } = req.body || {}
  try {
    const created = await prisma.inspection.create({
      data: {
        vehicleUnit: vehicle?.unitNumber || '',
        reportNumber: `R-${Date.now()}`,
        inspectorName: 'TBD',
        status: 'SUBMITTED',
        items
      }
    })
    res.json(created)
  } catch (e) {
    console.error(e)
    res.status(500).json({ error: 'Failed to create inspection' })
  }
})

r.get('/', async (req, res) => {
  const list = await prisma.inspection.findMany({ orderBy: { id: 'desc' }, take: 50 })
  res.json(list)
})

export default r