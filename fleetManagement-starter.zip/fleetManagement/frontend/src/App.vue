<template>
  <ion-app>
    <ion-router-outlet />
  </ion-app>
</template>

<script setup>
</script>