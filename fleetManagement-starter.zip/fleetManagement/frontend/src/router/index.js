import { createRouter, createWebHashHistory } from 'vue-router'

import Dashboard from '../pages/Dashboard.vue'
import NewInspection from '../pages/NewInspection.vue'
import Login from '../pages/Login.vue'

const routes = [
  { path: '/', redirect: '/dashboard' },
  { path: '/login', component: Login },
  { path: '/dashboard', component: Dashboard },
  { path: '/inspections/new', component: NewInspection },
]

const router = createRouter({
  history: createWebHashHistory(),
  routes
})

export default router