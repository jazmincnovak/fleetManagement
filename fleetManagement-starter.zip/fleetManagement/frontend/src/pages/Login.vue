<template>
  <ion-page>
    <ion-header>
      <ion-toolbar>
        <ion-title>Login</ion-title>
      </ion-toolbar>
    </ion-header>
    <ion-content class="ion-padding">
      <form @submit.prevent="submit">
        <ion-item>
          <ion-input v-model="email" type="email" label="Email" required></ion-input>
        </ion-item>
        <ion-item>
          <ion-input v-model="password" type="password" label="Password" required></ion-input>
        </ion-item>
        <ion-button expand="block" type="submit" class="mt-4">Sign In</ion-button>
      </form>
    </ion-content>
  </ion-page>
</template>

<script setup>
import { ref } from 'vue'
import api from '../api'
import { useRouter } from 'vue-router'
import { useUserStore } from '../store/user'
import { IonPage, IonHeader, IonToolbar, IonTitle, IonContent, IonItem, IonInput, IonButton } from '@ionic/vue'

const email = ref('')
const password = ref('')
const router = useRouter()
const user = useUserStore()

const submit = async () => {
  // Placeholder auth
  const res = await api.post('/auth/login', { email: email.value, password: password.value })
  localStorage.setItem('token', res.data.token)
  user.setToken(res.data.token)
  router.push('/dashboard')
}
</script>