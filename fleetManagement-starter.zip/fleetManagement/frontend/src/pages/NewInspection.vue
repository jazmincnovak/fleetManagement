<template>
  <ion-page>
    <ion-header>
      <ion-toolbar>
        <ion-title>New Inspection</ion-title>
      </ion-toolbar>
    </ion-header>
    <ion-content class="ion-padding">
      <ion-card>
        <ion-card-header>
          <ion-card-title>Vehicle</ion-card-title>
        </ion-card-header>
        <ion-card-content class="grid md:grid-cols-2 gap-3">
          <ion-input v-model="form.vehicle.vin" label="VIN"></ion-input>
          <ion-input v-model="form.vehicle.unitNumber" label="Unit #"></ion-input>
          <ion-input v-model="form.vehicle.year" label="Year" type="number"></ion-input>
          <ion-input v-model="form.vehicle.make" label="Make"></ion-input>
        </ion-card-content>
      </ion-card>

      <ion-card>
        <ion-card-header>
          <ion-card-title>Inspection Items</ion-card-title>
        </ion-card-header>
        <ion-card-content>
          <InspectionItem
            v-for="item in items"
            :key="item.key"
            :label="item.label"
            v-model="item.status"
            @update:repair="(r)=>item.repair=r"
          />
        </ion-card-content>
      </ion-card>

      <ion-button expand="block" class="mt-4" @click="submit">Submit</ion-button>
    </ion-content>
  </ion-page>
</template>

<script setup>
import { reactive } from 'vue'
import api from '../api'
import InspectionItem from '../components/InspectionItem.vue'
import { IonPage, IonHeader, IonToolbar, IonTitle, IonContent, IonCard, IonCardHeader, IonCardTitle, IonCardContent, IonButton, IonInput } from '@ionic/vue'

const form = reactive({
  vehicle: { vin: '', unitNumber: '', year: '', make: '' },
  items: []
})

const items = reactive([
  { key: 'service_brakes', label: 'Service brakes', status: 'OK', repair: null },
  { key: 'parking_brake', label: 'Parking brake', status: 'OK', repair: null },
  { key: 'tires_all', label: 'All tires', status: 'OK', repair: null },
  { key: 'lights_reflectors', label: 'Lights & reflectors', status: 'OK', repair: null }
])

const submit = async () => {
  const payload = {
    vehicle: form.vehicle,
    items: items.map(i => ({
      item: i.key,
      status: i.status,
      repair: i.status === 'NEEDS_REPAIR' ? i.repair : null
    }))
  }
  await api.post('/inspections', payload)
  alert('Submitted!')
}
</script>