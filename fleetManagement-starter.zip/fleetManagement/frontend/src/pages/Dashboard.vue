<template>
  <ion-page>
    <ion-header>
      <ion-toolbar>
        <ion-title>Dashboard</ion-title>
      </ion-toolbar>
    </ion-header>
    <ion-content class="ion-padding">
      <div class="space-y-4">
        <ion-card>
          <ion-card-header>
            <ion-card-title>Today's Jobs</ion-card-title>
          </ion-card-header>
          <ion-card-content>
            <p>Assigned inspections and repairs will appear here.</p>
            <ion-button router-link="/inspections/new" expand="block" class="mt-3">
              New Inspection
            </ion-button>
          </ion-card-content>
        </ion-card>
      </div>
    </ion-content>
  </ion-page>
</template>

<script setup>
import { IonPage, IonHeader, IonToolbar, IonTitle, IonContent, IonCard, IonCardHeader, IonCardTitle, IonCardContent, IonButton } from '@ionic/vue'
</script>