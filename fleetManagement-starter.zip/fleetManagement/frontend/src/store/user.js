import { defineStore } from 'pinia'

export const useUserStore = defineStore('user', {
  state: () => ({
    token: null,
    profile: null,
  }),
  actions: {
    setToken(t){ this.token = t },
    setProfile(p){ this.profile = p },
    logout(){ this.token = null; this.profile = null }
  }
})