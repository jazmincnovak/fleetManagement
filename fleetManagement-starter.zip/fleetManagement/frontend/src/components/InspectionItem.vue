<template>
  <div class="border rounded-xl p-3 mb-3">
    <div class="flex items-center justify-between">
      <span class="font-medium">{{ label }}</span>
      <div class="flex gap-2">
        <ion-segment :value="modelValue" @ionChange="onChange">
          <ion-segment-button value="OK">OK</ion-segment-button>
          <ion-segment-button value="NA">N/A</ion-segment-button>
          <ion-segment-button value="NEEDS_REPAIR">Needs Repair</ion-segment-button>
        </ion-segment>
      </div>
    </div>

    <div v-if="modelValue === 'NEEDS_REPAIR'" class="mt-3 space-y-2">
      <ion-input v-model="repairDate" label="Repair Date" type="date"></ion-input>
      <ion-textarea v-model="description" label="Description" auto-grow></ion-textarea>
    </div>
  </div>
</template>

<script setup>
import { ref, watch } from 'vue'
import { IonSegment, IonSegmentButton, IonInput, IonTextarea } from '@ionic/vue'

const props = defineProps({
  label: { type: String, required: true },
  modelValue: { type: String, default: 'OK' }
})
const emits = defineEmits(['update:modelValue', 'update:repair'])

const repairDate = ref('')
const description = ref('')

const onChange = (ev) => {
  const val = ev.detail?.value || 'OK'
  emits('update:modelValue', val)
}

watch([repairDate, description], () => {
  emits('update:repair', { date: repairDate.value, description: description.value })
})
</script>