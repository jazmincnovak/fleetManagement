import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.fleet.app',
  appName: 'Fleet Management',
  webDir: '../frontend/dist',
  bundledWebRuntime: false,
};

export default config;