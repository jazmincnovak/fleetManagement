# Mobile Wrapper

This Capacitor project points to `../frontend/dist` as the web assets folder.

Workflow:
1. In `frontend`: `npm run build`
2. In `mobile`: `npm install` (first time), then `npx cap sync`
3. `npx cap open ios` or `npx cap open android`