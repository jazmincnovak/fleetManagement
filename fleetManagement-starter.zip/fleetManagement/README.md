# Fleet Management – Starter Monorepo

Scaffold generated 2025-10-30.
This matches the structure we discussed (frontend + backend + mobile wrapper).

## Structure
```
fleetManagement/
├── frontend/        # Vue 3 + Vite + Ionic Vue + Pinia + Tailwind
├── backend/         # Node.js (Express) + Prisma + PostgreSQL
├── mobile/          # Capacitor wrapper pointing to ../frontend/dist
└── README.md
```

## Quickstart
### 1) Frontend
```
cd frontend
npm install
npm run dev
```

### 2) Backend
```
cd ../backend
cp .env.example .env    # update DATABASE_URL
npm install
npx prisma migrate dev --name init
npm run dev
```

### 3) Mobile (Capacitor)
After you can `npm run build` in `frontend`, then:
```
cd ../mobile
npm install
npx cap sync
npx cap open ios
npx cap open android
```

> Tip: Keep **hash mode** routing for now to simplify in-app navigation.

---

## Notes
- Replace placeholder package names, bundle IDs, and add real icons/splash in `/mobile/resources/`.
- Generated PDFs, signatures, and images are expected to be stored in S3 or equivalent (configure in backend `.env`).

Happy building!